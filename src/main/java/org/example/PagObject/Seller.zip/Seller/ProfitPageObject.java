package org.example.PagObject.Seller;

public class ProfitPageObject {
    String profitAmountValue = "";
}
