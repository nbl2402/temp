package org.example.PagObject.Seller;

public class ProductPageObject {
    String createRegularProductButton = "";
    String createPersonalizedProductButton = "";
    String CreateCampaignButton = "";

    String productCheckBox = "";

}
