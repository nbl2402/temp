package org.example.PagObject.Seller;

public class StoreTypesPageObject {

    String createNewStoreButton = "";
}
