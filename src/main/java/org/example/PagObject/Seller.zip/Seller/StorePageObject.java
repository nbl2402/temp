package org.example.PagObject.Seller;

public class StorePageObject {

    String moreInfoButton = "";
}
