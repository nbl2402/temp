package org.example.PagObject.Seller;

public class OrderPageObject {
    String filterTabs = "";

    String listingStatusOption = "";
    String artworkOption = "";
    String trackingOption = "";
    String personalizedItemOption  = "";
    String orderProgressStatusOption = "";

    String searchTextBox = "";
    String numberHyperlink = "";


}
